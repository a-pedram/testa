function testFunc(arg1,arg2,arg3)
disp( nargin)
    disp(arg2);
end