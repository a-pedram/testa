% 16	11 15 0.74159	15 16 0.737691	9 11 0.737068	13 16 0.729973	11 14 0.726991	11 13 0.718727	
% 15	8 15 0.749854	13 16 0.745897	7 9 0.735177	7 13 0.734417	11 15 0.729252	7 15 0.723697	
% 14	7 16 0.765895	2 12 0.748197	7 9 0.741746	7 11 0.730538	11 15 0.729038	8 9 0.723112	
% 13	7 15 0.771255	2 5 0.771099	11 15 0.76989	7 12 0.767084	11 12 0.766694	4 7 0.764472	
% 12	7 14 0.795463	7 15 0.789732	12 15 0.774256	10 11 0.76685	8 15 0.763575	11 15 0.759794	
% 11	4 10 0.782443	7 16 0.775699	2 3 0.77375	4 9 0.768955	12 16 0.767318	7 12 0.766538	
% 10	4 8 0.788641	4 7 0.784314	3 15 0.776634	1 3 0.775894	3 8 0.76915	4 15 0.76798	
% 9	13 15 0.802401	4 13 0.79328	11 15 0.790512	8 12 0.786964	12 16 0.78369	4 15 0.783612	
% 8	4 10 0.801154	4 15 0.798737	4 14 0.797801	4 13 0.797684	2 4 0.796242	10 15 0.788914	
% 7	4 10 0.809223	12 14 0.796398	8 13 0.793786	7 13 0.792656	5 13 0.792227	7 14 0.791876	
% 6	2 13 0.806144	13 14 0.804311	1 7 0.804194	4 11 0.801972	13 15 0.797451	13 16 0.797022
 p=1;
 wls=[16 15 13 16 15 14 15 15 15 14 13 ];
 is= [7  7  4  4  2  12 7  2  2  9  5  ];
 js= [16 11 16 16 6  15 13 10 13 12 9  ];
% .8201
%70 .7779  50 .7637!!  50pow33 .8647
% p2
% 6	12 14 0.811094	9 14 0.808491	12 16 0.797311	11 14 0.796955	12 15 0.796599	12 13 0.787217	
% 7	9 14 0.828136	2 14 0.818398	14 16 0.815139	12 14 0.814465	12 16 0.800101	11 14 0.795569	
% 8	2 16 0.824279	12 15 0.815083	12 14 0.809259	9 14 0.808997	12 13 0.802386	11 14 0.801936	
% 9	11 14 0.817499	15 16 0.806675	9 14 0.801356	5 12 0.800794	5 16 0.800644	11 15 0.800326	
% 10	2 4 0.836863	5 12 0.826957	12 14 0.82647	12 16 0.815757	9 13 0.79776	12 13 0.797217	
% 11	11 15 0.827987	5 16 0.827874	13 16 0.827237	9 16 0.822031	2 13 0.821376	9 13 0.817368
% 12	3 16 0.847819	12 14 0.83677	9 14 0.836639	2 16 0.834991	12 16 0.826694	11 16 0.824466	
% 13	2 14 0.82941	9 14 0.80821	12 13 0.805026	12 14 0.795344	5 16 0.794857	2 16 0.793322	
% 14	12 15 0.833736	12 14 0.82838	2 14 0.816956	9 14 0.815945	2 15 0.803304	9 13 0.801281	
% 15	9 13 0.828979	5 12 0.813445	1 14 0.806216	9 15 0.80306	12 15 0.801796	12 13 0.8013	
% 16	2 14 0.796562	9 12 0.79128	1 13 0.782085	4 14 0.777843	4 11 0.775783	2 13 0.773143
%  p=2;
%  wls=[10 12 10 14 14 14 12 11 ];
%  is= [5  12 12 12 3  5  14 3 ];
%  js= [12 16 14 15 14 12 16 5 ];
 
%0.8569
%70 8566  50 .8182   pow33 7883
% p3
% 6	5 6 0.779266	1 6 0.776489	2 5 0.772493	6 13 0.771817	5 15 0.771029	2 6 0.770598	
% 7	2 6 0.784595	6 13 0.7824	3 5 0.781968	1 5 0.781424	1 6 0.781086	6 15 0.777503	
% 8	5 6 0.80015	1 6 0.78923	2 5 0.775683	2 6 0.772699	1 5 0.770879	3 6 0.767839	
% 9	5 6 0.76388	3 6 0.761966	1 3 0.759002	7 12 0.754555	6 15 0.752491	3 15 0.75069	
% 10	2 7 0.780467	2 6 0.77724	5 7 0.776827	6 12 0.773787	3 6 0.75326	3 7 0.749826	
% 11	6 13 0.763205	6 15 0.750539	7 13 0.747631	6 9 0.74037	3 7 0.739882	2 6 0.737574	
% 12	3 5 0.777221	5 7 0.762567	3 6 0.743634	1 13 0.738475	3 7 0.737255	2 3 0.736279	
% 13	2 11 0.754592	3 15 0.754105	6 13 0.744666	13 16 0.741308	3 11 0.737658	2 7 0.736748	
% 14	5 11 0.74022	1 11 0.730425	3 8 0.722451	3 11 0.720874	11 12 0.719655	3 6 0.719345	
% 15	1 4 0.769143	6 14 0.74992	1 15 0.731813	11 15 0.726044	5 16 0.725303	6 11 0.724308	
% 16	5 6 0.743653	5 7 0.741101	6 15 0.730894	1 11 0.72883	4 13 0.727029	5 15 0.723257		
% p=3;
% wls=[13 10 12 13 8 6  11 ];
% is= [11 6  7  6  2 6  1  ];
% js= [16 11 8  8  6 13 8  ];
%0.8251
%70 0.8050 50 .8110 pow .33 .7959
%  load 'd:/datasetLettersWinL.mat';
%  load 'd:/lettersWinL.mat';
%  load '.\variables\letterNeighbors.mat';
close all;
Pow=.33
scoresS=[];
si=0;
ss=[];
numZeroFile=[500 1000 1000];
for pars=1:size(is,2);
    wl = wls(pars);
    i = is(pars);
    j= js(pars);
 %for wl=16:-1:6 

pLetters = datasetLetterWinL{wl}{p};
% for i=1:16
 %    for j=i+1:16
        tuples1= zeros(650,650);
tuples0= zeros(650,650);
tuples1F= zeros(650,650);
tuples0F= zeros(650,650);
fileFlag0=zeros(650,650);
fileFlag1=zeros(650,650);       
    file1C=0;file0C=0;
    for fn=1:size(pLetters,1)
        if pLetters{fn}.result==1            
            if file1C>50
                continue;
            end
            file1C = file1C+1;
        else
           if file1C>numZeroFile(p)
                continue;
            end
            file0C = file0C+1; 
        end
        numOfLetters= size(pLetters{fn}.data,1)-2;        
        for l =1:numOfLetters
            l1=pLetters{fn}.data(l,i);
            l2=pLetters{fn}.data(l,j);
            if pLetters{fn}.result==1
                tuples1(l1,l2)=tuples1(l1,l2)+1;
                if fileFlag1(l1,l2)~=fn
                    fileFlag1(l1,l2)=fn;
                    tuples1F(l1,l2)=tuples1F(l1,l2)+1;
                end
            else
                tuples0(l1,l2)=tuples0(l1,l2)+1;
                if fileFlag0(l1,l2)~=fn
                    fileFlag0(l1,l2)=fn;
                    tuples0F(l1,l2)=tuples0F(l1,l2)+1;
                end
            end
        end
    end
    tt= tuples1 ./ (tuples0+tuples1);
    tt(isnan(tt))=0;
    
    
    ff= tuples1F ./ (tuples0F+tuples1F);
    ff(isnan(ff))=0;
    
    fff= ff.* tuples1F;
% 
% scores=zeros(1302,1);
% results=zeros(1302,1);
scores=[];results=[];

file1C=0;file0C=0;fnn=0;
for fn=1:size(pLetters,1) 
    
    if pLetters{fn}.result==1            
        file1C = file1C+1;
        if file1C<50
            continue;
        end        
    else
        file0C = file0C+1; 
       if file0C<numZeroFile(p)
            continue;
       end        
    end
    numOfLetters= size(pLetters{fn}.data,1)-2;
    sq=0;
    score=0;
    for l =1:numOfLetters
        l1=pLetters{fn}.data(l,i);
        l12 = letterNeighbors{wl}{p}{i}(l1);
        l2=pLetters{fn}.data(l,j);
        l22 = letterNeighbors{wl}{p}{j}(l2);        
%         sq = sq+4;%(tuples1F(l1,l2)+tuples0F(l1,l2))^.33;% log(tuples1F(l1,l2)+1);
%         score = score + ff(l1,l2)+ff(l1,l22)+ff(l2,l12)+ff(l12,l22) ;% *(tuples1F(l1,l2)+tuples0F(l1,l2))^.33;%(log(tuples1F(l1,l2)+1));
        
        sq = sq+(tuples1F(l1,l2))^Pow;% log(tuples1F(l1,l2)+1);
        sq = sq+(tuples1F(l1,l22))^Pow;
        sq = sq+(tuples1F(l2,l12))^Pow;
        sq = sq+(tuples1F(l12,l22))^Pow;
        score = score + ff(l1,l2) *(tuples1F(l1,l2))^Pow ...
                +ff(l1,l22)* (tuples1F(l1,l22))^Pow ...
                +ff(l2,l12)* (tuples1F(l2,l12))^Pow ...
                +ff(l12,l22)*(tuples1F(l12,l22))^Pow ;% *(tuples1F(l1,l2)+tuples0F(l1,l2))^.33;%(log(tuples1F(l1,l2)+1));        
    end
    fnn=fnn+1;
    scores(fnn)=score/sq;
    results(fnn)=pLetters{fn}.result;
    %fprintf('fn:%d file:%s,score:%g \n',fn,pLetters{fn}.fileName ,scores(fn));
end
%au=AUC(scores,results);
si=si+1;
[x,y,t ,au(si)]= perfcurve(results,scores,1);
%figure;plot(x,y);
scoresS(si,:)=scores;
    fprintf('wl:%d i:%d j:%d s:%g\n',wl,i,j, au(si));        
    ss(si,:)=[i j au(si)];
     %end
    %fprintf('wl:%d i:%d \n',wl,i); 
 end
ss = sortrows(ss,-3);
% for kk=1:6
%     fprintf('%d %d %g\t',ss(kk,1),ss(kk,2),ss(kk,3));
% end
%fprintf('\n');
%ss(1:6,:)
%end

scoresS=sum(scoresS)/size(is,2);
[x,y,t ,aus]= perfcurve(results,scoresS,1);
aus
figure;plot(x,y);

r1 = results;
sc1 = scoresS;

results=[r1 r2 r3];
%.8639 [sc1*.49 sc2*1.01 sc3*.72 ];
scoresS=[sc1*.73 sc2*1.14 sc3 ];
scoresS=[sc1*.36 sc2 sc3*.74];
[x,y,t ,aus]= perfcurve(results,scoresS,1);
aus

%**************** i:0.54	j:1	k:0.66	AUC:0.892779
% for i=.53:.02:.57
%     for j=1:1
%         for k=.58:.02:.68
%             scoresS=[sc1*i sc2*j sc3*k ];
%             [x,y,t ,aus]= perfcurve(results,scoresS,1);
%             fprintf('i:%g\tj:%g\tk:%g\tAUC:%g\n',i,j,k,aus);
%         end
%     end
% end

